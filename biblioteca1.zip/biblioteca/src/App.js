import logo from './logo.svg';
import './App.css';
import BookDashboard from './components/BookDashboard'

function App() {
  
  return (
    <div className="App">
        <h1>A minha biblioteca</h1>
        <BookDashboard />
    </div>
  );
}

export default App;
