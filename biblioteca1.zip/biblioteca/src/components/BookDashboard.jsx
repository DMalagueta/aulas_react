import React from 'react'
import BookList from './BookList.jsx'
import {data} from '../data'
import { useState } from 'react'
import BookForm from './BookForm'

/* let arrayBooks =[
    {
        "id":0,
        "title":"Angular com Typescript",
        "author":"Yakov Fain",
        "alreadyRead":true,
        "imageUrl":"angular.jpg",
        "imageUrlGr":"angularGr.png",
        "description":"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium."
     },
     {
        "id":1,
        "title":"Blockchain com JS",
        "author":"Bina Ramahurty",
        "alreadyRead":false,
        "imageUrl":"blockchain.jpg",
        "imageUrlGr":"blockchainGr.png",
        "description":"Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sed vitae inventore nostrum nobis! Quia, iure totam quaerat expedita laboriosam quo omnis culpa vero provident! Quis pariatur accusantium nesciunt recusandae praesentium."
     },
] */



export default function BookDashboard(props) {
    const [books, setBooks] = useState(data.books)
    
    const handleDelete = (id) => {
        console.log('livro para apagar', id)
    
        setBooks( books.filter(b => b.id !== id))
    }

    const handleAddBook = (book) =>{
        console.log(book)
        setBooks([book, ...books])
    }


  return (
    <div>
        <BookForm 
            onFormSubmit={handleAddBook}
        />
        <BookList 
            books={books} 
            onDelete={handleDelete}   
        />
    </div>
  )
}

