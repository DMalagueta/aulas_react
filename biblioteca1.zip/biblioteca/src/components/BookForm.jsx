import React, { useState } from 'react'

export default function BookForm(props) {

    const [title, setTitle] = useState('');
    const [author, setAuthor] = useState('');
    const [alreadyRead, setAlreadyRead] = useState('');
    const [imgUrl, setImgUrl] = useState('');

    const handleSubmit = (e) => {

        /* let newBook = {
            title: title,
            author: author,
            already: false,
            imgUrl:imgUrl,
         } */
         
        let id = new Date().getTime();

        let newBook = {
           id,
           title,
           author,
           alreadyRead,
           imgUrl,
        }

        props.onFormSubmit(newBook);
        setTitle('');
        setAuthor('');
        setImgUrl('');
        setAlreadyRead(false);
        e.preventDefault();
    }

  return (
    <>
        <section className="acrescentar">
                <form>
                    <div>
                        <label htmlFor="title">Title:</label>
                        <input type="text" id="title" value={title} onChange={({target:{value}})=>setTitle(value)} />
                    </div>
                    <div>
                        <label htmlFor="author">Author:</label>
                        <input type="text" id="author" value={author} onChange={(e)=>setAuthor(e.target.value)}/>
                    </div>
                    <div>
                        <label htmlFor="alreadyRead">Ja lido:</label>
                        <input type="checkbox" id="alreadyRead" checked={alreadyRead} onChange={(e)=>setAlreadyRead(e.target.checked)}/>
                    </div> 
                    <div>
                        <label htmlFor="imgUrl">Miniatura</label>
                        <input type="text" id="imgUrl" value={imgUrl} onChange={(e)=>setImgUrl(e.target.value)}/>
                    </div>
                    <div>
                        <button onClick={handleSubmit}>Acrescentar Livro</button>
                    </div>
                </form>
        </section>
    </>
  )
}
